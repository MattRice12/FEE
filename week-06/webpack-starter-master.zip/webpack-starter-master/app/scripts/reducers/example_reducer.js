export default function exampleReducer (state, action) {
  return state;
}
