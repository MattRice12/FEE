export default {
  allState: function (state) {
    return state;
  }
}
