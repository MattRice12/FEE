import React from 'react'

class About extends React.Component {
  render () {
    return (
      <main>
        <h3>About Navigation</h3>
        <p>
          By using react-router we can now have multiple 'pages' of our application.
        </p>
      </main>
    );
  }
}

export default About
