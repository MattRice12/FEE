export default function AppReducer (state, action) {
  if (state === undefined) {
    return {};
  }
  return state;
}
