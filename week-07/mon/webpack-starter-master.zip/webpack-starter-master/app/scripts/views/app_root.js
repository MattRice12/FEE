import React from 'react'

export default React.createClass({
  render: function () {
    return (
      <section>
        <h1>Whoa!</h1>
      </section>
    );
  }
});
