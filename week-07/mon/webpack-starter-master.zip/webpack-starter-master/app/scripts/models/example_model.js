export default function ExampleModel (attrs) {
  this.id = attrs.id
  this.name = attrs.name || "No Name Given"
}
