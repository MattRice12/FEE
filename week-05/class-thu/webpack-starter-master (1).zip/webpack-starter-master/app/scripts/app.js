
export default function app() {

    console.log(Redux.store('foo'));
}
